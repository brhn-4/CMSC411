#include "mips-small-pipe.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/************************************************************/
int main(int argc, char *argv[]) {
  short i;
  char line[MAXLINELENGTH];
  state_t state;
  FILE *filePtr;

  if (argc != 2) {
    printf("error: usage: %s <machine-code file>\n", argv[0]);
    return 1;
  }

  memset(&state, 0, sizeof(state_t));

  state.pc = state.cycles = 0;
  state.IFID.instr = state.IDEX.instr = state.EXMEM.instr = state.MEMWB.instr =
      state.WBEND.instr = NOPINSTRUCTION; /* nop */

  /* read machine-code file into instruction/data memory (starting at address 0)
   */

  filePtr = fopen(argv[1], "r");
  if (filePtr == NULL) {
    printf("error: can't open file %s\n", argv[1]);
    perror("fopen");
    exit(1);
  }

  for (state.numMemory = 0; fgets(line, MAXLINELENGTH, filePtr) != NULL;
       state.numMemory++) {
    if (sscanf(line, "%x", &state.dataMem[state.numMemory]) != 1) {
      printf("error in reading address %d\n", state.numMemory);
      exit(1);
    }
    state.instrMem[state.numMemory] = state.dataMem[state.numMemory];
    printf("memory[%d]=%x\n", state.numMemory, state.dataMem[state.numMemory]);
  }

  printf("%d memory words\n", state.numMemory);

  printf("\tinstruction memory:\n");
  for (i = 0; i < state.numMemory; i++) {
    printf("\t\tinstrMem[ %d ] = ", i);
    printInstruction(state.instrMem[i]);
  }

  run(&state);

  return 0;
}
/************************************************************/

/************************************************************/
void run(Pstate state) {
  state_t new;
  int curr;
  int currFunc = 0;
  int p1,p2,p3,prevOP1,prevOP2,prevOP3;
  int s1,s2,regA,regB;
  int offSet;
  int cycles = 0;
  int finalCycles = 0;
    
  memset(&new, 0, sizeof(state_t));

  while (1) {

    printState(state);

    /* copy everything so all we have to do is make changes.
       (this is primarily for the memory and reg arrays) */
    memcpy(&new, state, sizeof(state_t));

    new.cycles++;

    /* --------------------- IF stage --------------------- */
    new.IFID.instr= new.instrMem[new.pc/4];
    curr = new.IFID.instr;
    new.pc = new.pc + 4; 

    if((opcode(new.IFID.instr) != BEQZ_OP)){
      new.IFID.pcPlus1 = new.pc;
    }else{
      offSet = offset(curr);
      if(offSet > 0){
        new.IFID.pcPlus1 = new.pc;
      }else{
        new.pc = new.pc + offSet;
        new.IFID.pcPlus1 = new.pc - offSet;
      }
    }
   /* --------------------- ID stage --------------------- */
    new.IDEX.instr = state->IFID.instr;
    curr = new.IDEX.instr;

    new.IDEX.readRegA = new.reg[field_r1(curr)];
    new.IDEX.readRegB = new.reg[field_r2(curr)];
    new.IDEX.offset = offset(curr);
    new.IDEX.pcPlus1 = state->IFID.pcPlus1;
    

    if (((field_r1(curr) == field_r2(state->IDEX.instr)) || (field_r2(curr) == field_r2(state->IDEX.instr)))&&((opcode(curr) == REG_REG_OP) && (opcode(state->IDEX.instr) == LW_OP)) ) {
      new.IDEX.instr = NOPINSTRUCTION;
      new.IDEX.pcPlus1 = 0;
      new.IDEX.readRegA = new.IDEX.readRegB = 0;
      new.IDEX.offset = offset(NOPINSTRUCTION);
      new.IFID.instr = state->IFID.instr;
      curr = new.IFID.instr;
      new.pc = new.pc - 4;
      new.IFID.pcPlus1 = new.pc;
      cycles = cycles + 1;
      
    }
    else if (((opcode(curr) != HALT_OP) &&
	     (opcode(state->IDEX.instr) == LW_OP)) &&(field_r1(curr) == field_r2(state->IDEX.instr))) {
        new.IDEX.instr = NOPINSTRUCTION;
        new.IDEX.pcPlus1 = 0;
        new.IDEX.readRegA = 0;
        new.IDEX.readRegB = 0;
        new.IDEX.offset = offset(NOPINSTRUCTION);
        new.IFID.instr = state->IFID.instr;
        curr = new.IFID.instr;
        new.pc = new.pc + 4;
        new.IFID.pcPlus1 = new.pc;
        cycles = cycles + 1;
      
    }

    /*set var to states....  EXE,MEM,WB,END */
    p1 = state->EXMEM.instr;
    p2 = state->MEMWB.instr;
    p3 = state->WBEND.instr;
    prevOP1 = opcode(p1);
    prevOP2 = opcode(p2);
    prevOP3 = opcode(p3);
    /*forwarding*/
    /*REGs*/
    regA = new.reg[field_r1(curr)];
    regB = new.reg[field_r2(curr)];
    
    s1 = field_r1(curr);
    s2 = field_r2(curr);
    /*correct order now*/
    /*exmem*/
    if(prevOP1 == REG_REG_OP){
      if(s1!=0 && s1 == field_r3(p1)){
        regA = state->EXMEM.aluResult;
      }
      if(s2!=0 && s2 == field_r3(p1)){
        regB = state->EXMEM.aluResult;
      }
    }else if((prevOP1 == LW_OP || prevOP1 == ADDI_OP || prevOP1 == BEQZ_OP) &&
     (prevOP1 != opcode(NOPINSTRUCTION))){
        if(s1!=0 && s1 == field_r2(p1)){
          regA = state->EXMEM.aluResult;
        }
        if(s2!=0 && s2 == field_r2(p1) && opcode(curr) != prevOP1){
          regB = state->EXMEM.aluResult;
        }

    }

    /*MEMWB*/  
    if(prevOP2 == REG_REG_OP && prevOP2 != opcode(NOPINSTRUCTION)){
      if(s1 != 0 && s1 == field_r3(p2)){
        regA = state->MEMWB.writeData;
      }
      if(s2 != 0 && s2 == field_r3(p2)){
        regB = state->MEMWB.writeData;
      }
    }else if ((prevOP2 == LW_OP || prevOP2 == ADDI_OP || prevOP2 == BEQZ_OP)&& prevOP2 != opcode(NOPINSTRUCTION)){
      if(s1!=0 && s1==field_r2(p2)){
        regA = state->MEMWB.writeData;
      }
      if(s2!=0 && s2 == field_r2(p2)){
        regB = state->MEMWB.writeData;
      }
    }
    /*WBEND*/
    if(prevOP3 == SW_OP &&(prevOP3 != opcode(NOPINSTRUCTION))){ /*check for SW*/
      if(s2 != 0 && s2 == field_r2(p3)){
        regB =state->EXMEM.aluResult;
      }
    }else if (prevOP3 == REG_REG_OP){ /*reg-reg operator*/
      if(s1 != 0 && s1 == field_r3(prevOP3)){
        regA = state->WBEND.writeData;
      }
      if(s2 != 0 && s2 == field_r3(prevOP3)){
        regB = state->WBEND.writeData;
      }
    }else if ((prevOP3 == BEQZ_OP)|| (prevOP3 == LW_OP) || (prevOP3 == ADDI_OP)){ /*bqez, lw, addi*/
      if(s1!=0 && s1==field_r2(p3)){
        regA = state->WBEND.writeData;
      }
      if(s2!=0 && s2==field_r2(p3)){
        regB = state->WBEND.writeData;
      }
    }
    

    if(opcode(curr) == LW_OP){ /*LW*/
      new.EXMEM.aluResult = regA + field_imm(curr);
      new.EXMEM.readRegB = new.reg[field_r2(curr)];
    } else if (opcode(curr) == SW_OP){ /*SW*/
      new.EXMEM.readRegB = regB;
      new.EXMEM.aluResult = regA + field_imm(curr);
    } else if (opcode(curr) == ADDI_OP){ /*ADDI*/
      new.EXMEM.aluResult = regA + offset(curr);
      new.EXMEM.readRegB = state->IDEX.readRegB;
    } else if (opcode(curr) == REG_REG_OP){ /*REG REG*/
        if(curr == NOPINSTRUCTION){
          new.EXMEM.aluResult = 0;
	        new.EXMEM.readRegB = 0;
        }
        else if(currFunc ==AND_FUNC){
          new.EXMEM.aluResult = regB & regA;
          new.EXMEM.readRegB = regB;
        }
        else if(currFunc == OR_FUNC){
          new.EXMEM.aluResult = regB | regA;
          new.EXMEM.readRegB = regB;
        }
        else if(currFunc == SUB_FUNC){
          new.EXMEM.aluResult = regA-regB;
          new.EXMEM.readRegB = regB;
        }
        else if (currFunc == ADD_FUNC){
          new.EXMEM.aluResult = regA+regB;
          new.EXMEM.readRegB = regB;
        }
        else if (currFunc ==SLL_FUNC){
          new.EXMEM.aluResult = regA<<regB;
          new.EXMEM.readRegB = regB;
        }
        else if(currFunc == SRL_FUNC){ 
          new.EXMEM.aluResult = ((unsigned int) regA)>> regB;
          new.EXMEM.readRegB = regB;
        }
        else{exit(0);}
    }
    else if(opcode(curr) == BEQZ_OP){ /*BQEZ. potential fixed error. had wrong way*/
      if((state->IDEX.offset >= 0 || regA==0) && (state->IDEX.offset <= 0 || regA!=0)) {
        new.EXMEM.readRegB = new.reg[field_r2(curr)];
        new.EXMEM.aluResult = state->IDEX.pcPlus1 + offset(curr); 
      }
      else{     
        new.IFID.instr = NOPINSTRUCTION;
        new.IDEX.instr = NOPINSTRUCTION;
        new.pc = state->IDEX.offset + state->IDEX.pcPlus1; 
        new.IFID.pcPlus1 = 0;
        new.IDEX.pcPlus1 = 0;
        new.IDEX.readRegA = 0;
        new.IDEX.readRegB = 0; /*resetin*/
        new.IDEX.offset = 32;
        new.EXMEM.aluResult = state->IDEX.pcPlus1 + offset(curr);
        new.EXMEM.readRegB = new.reg[field_r2(curr)];
      } 
    }else{
      new.EXMEM.aluResult = 0;
      new.EXMEM.readRegB = 0;
    }

    new.MEMWB.instr = state->EXMEM.instr; /*MEM->WB*/
    curr = new.MEMWB.instr;
    
    if(opcode(curr) == ADDI_OP){ /*ADDI*/
      new.MEMWB.writeData = state->EXMEM.aluResult;
    }
    else if (opcode(curr) == LW_OP){ /*LW*/
      new.MEMWB.writeData = state->dataMem[state->EXMEM.aluResult/4];
    }
    else if (opcode(curr) == SW_OP){ /*SW*/
      new.MEMWB.writeData = state->EXMEM.readRegB;
      new.dataMem[(new.reg[field_r1(curr)] + field_imm(curr))/4] = new.MEMWB.writeData;
    }
    else if (opcode(curr) == REG_REG_OP){ /*REG REG*/
      new.MEMWB.writeData = state->EXMEM.aluResult;
    }
    else if (opcode(curr) == BEQZ_OP){ /*BEQZ*/
      new.MEMWB.writeData = state->EXMEM.aluResult;
    }
    else if (opcode(curr) == HALT_OP){ /*HALT*/
      new.MEMWB.writeData = 0;
    }


    /* --------------------- WB stage --------------------- */
    new.WBEND.instr = state->MEMWB.instr;
    curr = new.WBEND.instr;

    if(opcode(curr) == LW_OP){
      new.WBEND.writeData = state->MEMWB.writeData;
      new.reg[field_r2(curr)] = new.WBEND.writeData;
    }
    else if (opcode(curr) == SW_OP){
      new.WBEND.writeData = state->MEMWB.writeData;
    }
    else if (opcode(curr) == REG_REG_OP){
      new.reg[field_r3(curr)] = state->MEMWB.writeData;
      new.WBEND.writeData = state->MEMWB.writeData;
    }
    else if (opcode(curr) == ADDI_OP){
      new.WBEND.writeData = state->MEMWB.writeData;
      new.reg[field_r2(curr)] = new.WBEND.writeData;
    }
    else if (opcode(curr) == BEQZ_OP){
       new.WBEND.writeData = state->MEMWB.writeData;
    }
    else if (opcode(curr) == HALT_OP){
      finalCycles = state->cycles;
      printf("machinehalted\ntotal of %d cycles executed",finalCycles);
      exit(0);
    }
    /* --------------------- end stage --------------------- */
    

    /* transfer new state into current state */
    regA = 0;
    regB = 0;
    memcpy(state, &new, sizeof(state_t));
  }
}
/************************************************************/

/************************************************************/
int opcode(int instruction) { return (instruction >> OP_SHIFT) & OP_MASK; }
/************************************************************/

/************************************************************/
int func(int instruction) { return (instruction & FUNC_MASK); }
/************************************************************/

/************************************************************/
int field_r1(int instruction) { return (instruction >> R1_SHIFT) & REG_MASK; }
/************************************************************/

/************************************************************/
int field_r2(int instruction) { return (instruction >> R2_SHIFT) & REG_MASK; }
/************************************************************/

/************************************************************/
int field_r3(int instruction) { return (instruction >> R3_SHIFT) & REG_MASK; }
/************************************************************/

/************************************************************/
int field_imm(int instruction) { return (instruction & IMMEDIATE_MASK); }
/************************************************************/

/************************************************************/
int offset(int instruction) {
  /* only used for lw, sw, beqz */
  return convertNum(field_imm(instruction));
}
/************************************************************/

/************************************************************/
int convertNum(int num) {
  /* convert a 16 bit number into a 32-bit Sun number */
  if (num & 0x8000) {
    num -= 65536;
  }
  return (num);
}
/************************************************************/

/************************************************************/
void printState(Pstate state) {
  short i;
  printf("@@@\nstate before cycle %d starts\n", state->cycles);
  printf("\tpc %d\n", state->pc);

  printf("\tdata memory:\n");
  for (i = 0; i < state->numMemory; i++) {
    printf("\t\tdataMem[ %d ] %d\n", i, state->dataMem[i]);
  }
  printf("\tregisters:\n");
  for (i = 0; i < NUMREGS; i++) {
    printf("\t\treg[ %d ] %d\n", i, state->reg[i]);
  }
  printf("\tIFID:\n");
  printf("\t\tinstruction ");
  printInstruction(state->IFID.instr);
  printf("\t\tpcPlus1 %d\n", state->IFID.pcPlus1);
  printf("\tIDEX:\n");
  printf("\t\tinstruction ");
  printInstruction(state->IDEX.instr);
  printf("\t\tpcPlus1 %d\n", state->IDEX.pcPlus1);
  printf("\t\treadRegA %d\n", state->IDEX.readRegA);
  printf("\t\treadRegB %d\n", state->IDEX.readRegB);
  printf("\t\toffset %d\n", state->IDEX.offset);
  printf("\tEXMEM:\n");
  printf("\t\tinstruction ");
  printInstruction(state->EXMEM.instr);
  printf("\t\taluResult %d\n", state->EXMEM.aluResult);
  printf("\t\treadRegB %d\n", state->EXMEM.readRegB);
  printf("\tMEMWB:\n");
  printf("\t\tinstruction ");
  printInstruction(state->MEMWB.instr);
  printf("\t\twriteData %d\n", state->MEMWB.writeData);
  printf("\tWBEND:\n");
  printf("\t\tinstruction ");
  printInstruction(state->WBEND.instr);
  printf("\t\twriteData %d\n", state->WBEND.writeData);
}
/************************************************************/

/************************************************************/
void printInstruction(int instr) {

  if (opcode(instr) == REG_REG_OP) {

    if (func(instr) == ADD_FUNC) {
      print_rtype(instr, "add");
    } else if (func(instr) == SLL_FUNC) {
      print_rtype(instr, "sll");
    } else if (func(instr) == SRL_FUNC) {
      print_rtype(instr, "srl");
    } else if (func(instr) == SUB_FUNC) {
      print_rtype(instr, "sub");
    } else if (func(instr) == AND_FUNC) {
      print_rtype(instr, "and");
    } else if (func(instr) == OR_FUNC) {
      print_rtype(instr, "or");
    } else {
      printf("data: %d\n", instr);
    }

  } else if (opcode(instr) == ADDI_OP) {
    print_itype(instr, "addi");
  } else if (opcode(instr) == LW_OP) {
    print_itype(instr, "lw");
  } else if (opcode(instr) == SW_OP) {
    print_itype(instr, "sw");
  } else if (opcode(instr) == BEQZ_OP) {
    print_itype(instr, "beqz");
  } else if (opcode(instr) == HALT_OP) {
    printf("halt\n");
  } else {
    printf("data: %d\n", instr);
  }
}
/************************************************************/

/************************************************************/
void print_rtype(int instr, const char *name) {
  printf("%s %d %d %d\n", name, field_r3(instr), field_r1(instr),
         field_r2(instr));
}
/************************************************************/

/************************************************************/
void print_itype(int instr, const char *name) {
  printf("%s %d %d %d\n", name, field_r2(instr), field_r1(instr),
         offset(instr));
}
/************************************************************/
